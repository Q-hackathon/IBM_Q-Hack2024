<script>
</script>

<div class="curriculum">
    <h1>Curriculum</h1>
    <div class="card">
        <p>Forests</p>
        <p>97/100</p>
    </div>
    <div class="card">
        <p>Wildlife</p>
        <p>82/100</p>
    </div>
    <div class="card">
        <p>Cells</p>
        <p>66/100</p>
    </div>
    <div class="card">
        <p>Digestion</p>
        <p>40/100</p>
    </div>
</div>


<style>
    .curriculum{
        width: 100%;
        background-color: var(--background);
        border-radius: 5px;
        padding-bottom: 1rem;
    }

    p {
        font-size: 1.2rem;
    }

    h1{
        text-align: center;
        padding: 0;
        margin: 0;
        color: var(--accent);
    }

    .card{
        width: calc(100% - 2rem);
        display: flex;
        justify-content: space-between;
        padding: 0rem 1rem;
        gap: 1rem;
        border-bottom: 4px solid rgba(255, 255, 255, 0.1);

        padding-bottom: 1rem;
        padding-top: 1rem;
    }
</style>
