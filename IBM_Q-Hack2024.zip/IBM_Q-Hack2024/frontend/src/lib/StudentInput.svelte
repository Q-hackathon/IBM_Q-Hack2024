<script lang="ts">
    import selectedVideo from "../general/stores";

    // Speichert den student input in einer globalen variable
    // const handleChange = (event: Event) => {
    //     selectedVideo.set((event.target as HTMLInputElement).value);
    // }
</script>

<div>selectedVideo
    <!-- <input on:change={handleChange}> -->
</div>

<style>
    div{
        background-color: var(--background);
    }
</style>
